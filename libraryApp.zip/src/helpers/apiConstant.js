export const BOOK = `book`;
export const USER = `user`;
export const TRNSACTION = `transaction`;
export const DASHBOARD = `book/dashboard`;
export const SIGN_IN = `auth/sign-in`;
