export const pageTitle = (title) => {
  return (document.title = title + " -  Library React App");
};
