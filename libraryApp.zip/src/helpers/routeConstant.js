export const BOOK_LIST_ROUTE = `booklist`;
